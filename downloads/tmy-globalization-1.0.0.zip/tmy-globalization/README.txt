Globalization Plugin for WordPress

Contributors: Yu Shao
Tags: i18n, l10n, translation, localization, globalization
Requires at least: 3.7
Tested up to: 4.9
Stable tag: 0.3
License: GPLv2 or later


Description

SS
